public abstract class Mammal
{

	 public void generateHeat()
	 {
		System.out.println("Generating Heat");
	 }
	 
	 public abstract void makeNoise();
	
}