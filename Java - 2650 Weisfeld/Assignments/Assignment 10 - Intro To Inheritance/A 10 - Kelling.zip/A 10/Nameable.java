public interface Nameable										//Don't define methods in interface, only declare them 
{     

     public void setName(String name); 		
	 
     public abstract String getName(); 
	 
}