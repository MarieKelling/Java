public class TestDog 
{

	 public static void main(String[] args) 
	 {

		 Dog fido = new Dog();

		 fido.makeNoise();

		 fido.setName("Fido");
		 System.out.println("Name = " + fido.getName());
	 } 
}